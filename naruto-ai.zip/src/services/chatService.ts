import axios from 'axios';

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export async function sendMessageToAI(message: string): Promise<string> {
  const response = await axios.post('/api/chat', { message });
  const data = response.data;
  
  // Per requirements: response is {"reply": "AI response"}
  return data.reply || data.response || data.message || (typeof data === 'string' ? data : JSON.stringify(data));
}

