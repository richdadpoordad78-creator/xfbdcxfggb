/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Bot, Loader2, Sparkles, Trash2, Github, Moon, Sun } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { sendMessageToAI, Message } from './services/chatService';

// Typewriter component for the AI reply effect
const Typewriter = ({ text, onComplete }: { text: string; onComplete?: () => void }) => {
  const [displayedText, setDisplayedText] = useState('');
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (index < text.length) {
      const timeout = setTimeout(() => {
        setDisplayedText((prev) => prev + text[index]);
        setIndex((prev) => prev + 1);
      }, 15); // Adjust typing speed here
      return () => clearTimeout(timeout);
    } else if (onComplete) {
      onComplete();
    }
  }, [index, text, onComplete]);

  return (
    <div className="prose prose-invert prose-sm max-w-none">
      <ReactMarkdown>{displayedText}</ReactMarkdown>
    </div>
  );
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await sendMessageToAI(userMessage);
      setMessages((prev) => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error('Chat error:', error);
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Oops! Something went wrong while calling the API. Please check your connection and try again.' },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  return (
    <div className={`flex flex-col h-screen transition-colors duration-300 ${isDarkMode ? 'bg-[#212121] text-gray-100' : 'bg-white text-gray-900'}`}>
      {/* Header */}
      <header className={`h-14 flex items-center justify-between px-4 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
        <div className="flex items-center gap-2 font-bold tracking-tight">
          <div className="bg-[#FF6321] p-1 rounded-md">
            <Sparkles size={18} className="text-white" />
          </div>
          <span>Naruto AI</span>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-lg transition-colors ${isDarkMode ? 'hover:bg-white/10' : 'hover:bg-black/5'}`}
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button 
            onClick={clearChat}
            className={`p-2 rounded-lg transition-colors text-gray-400 hover:text-red-400 ${isDarkMode ? 'hover:bg-white/10' : 'hover:bg-black/5'}`}
            title="Clear Chat"
          >
            <Trash2 size={20} />
          </button>
        </div>
      </header>

      {/* Main Chat Window */}
      <main className="flex-1 overflow-y-auto w-full max-w-4xl mx-auto px-4 py-8 space-y-6">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-70 mt-20">
            <div className="w-16 h-16 rounded-full bg-gray-500/10 flex items-center justify-center mb-4">
              <Bot size={40} className="text-[#FF6321]" />
            </div>
            <h2 className="text-2xl font-bold">How can I help you today?</h2>
            <p className="text-sm max-w-md">Start a conversation with Naruto AI. I can help with coding, writing, or just answering questions.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {messages.map((msg, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-4 ${msg.role === 'assistant' ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`flex gap-4 max-w-3xl ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
                    msg.role === 'user' ? 'bg-[#FF6321] text-white' : (isDarkMode ? 'bg-gray-700' : 'bg-gray-200')
                  }`}>
                    {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
                  </div>
                  <div className={`px-4 py-3 rounded-2xl shadow-sm ${
                    msg.role === 'user' 
                      ? (isDarkMode ? 'bg-[#303030] rounded-tr-none' : 'bg-gray-100 rounded-tr-none')
                      : (isDarkMode ? 'bg-[#2f2f2f] rounded-tl-none border border-white/5' : 'bg-white rounded-tl-none border border-gray-200')
                  }`}>
                    <div className={`text-sm font-semibold mb-1 opacity-50 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                      {msg.role === 'user' ? 'You' : 'Naruto'}
                    </div>
                    <div className={`prose prose-sm max-w-none break-words ${isDarkMode ? 'prose-invert' : ''}`}>
                      {msg.role === 'assistant' && idx === messages.length - 1 && isLoading === false ? (
                        <Typewriter text={msg.content} onComplete={scrollToBottom} />
                      ) : (
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-4 justify-start"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 animate-pulse ${isDarkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                  <Bot size={18} />
                </div>
                <div className={`px-4 py-4 rounded-2xl rounded-tl-none border ${isDarkMode ? 'bg-[#2f2f2f] border-white/5 text-gray-400' : 'bg-white border-gray-200 text-gray-500'}`}>
                  <div className="flex items-center gap-2">
                    <Loader2 size={16} className="animate-spin text-[#FF6321]" />
                    <span className="text-xs italic">Naruto is writing...</span>
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={chatEndRef} className="h-1" />
          </div>
        )}
      </main>

      {/* Input Section */}
      <footer className={`p-4 pb-8 ${isDarkMode ? 'bg-[#212121]' : 'bg-white'}`}>
        <form 
          onSubmit={handleSendMessage}
          className={`relative max-w-4xl mx-auto flex items-center rounded-2xl border transition-all shadow-lg ${
            isDarkMode 
              ? 'bg-[#303030] border-white/10 focus-within:border-white/20' 
              : 'bg-white border-gray-200 focus-within:border-gray-300'
          }`}
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={isLoading ? "Please wait for response..." : "Message Naruto AI..."}
            className="w-full bg-transparent px-5 py-4 focus:outline-none resize-none min-h-[56px] max-h-48 scrollbar-hide text-base"
            rows={1}
          />
          <div className="pr-3 flex items-center">
            <button 
              type="submit"
              disabled={!input.trim() || isLoading}
              className={`p-2 rounded-xl transition-all ${
                input.trim() && !isLoading 
                  ? 'bg-[#FF6321] text-white shadow-sm hover:scale-105 active:scale-95' 
                  : 'bg-white/5 text-gray-500'
              }`}
            >
              <Send size={20} />
            </button>
          </div>
        </form>
        <p className="mt-3 text-center text-[10px] text-gray-500 max-w-md mx-auto">
          Naruto AI can make mistakes. Consider checking important information. 
          <a href="#" className="underline ml-1">Terms & Privacy</a>
        </p>
      </footer>
    </div>
  );
}


